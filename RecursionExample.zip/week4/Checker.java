public class Checker {
    BombSquare k;
    int count;
    GameBoard b;
    
    private String[] filename ;
    public Checker(BombSquare sq, GameBoard board){
        k = sq; ///square thats been clicked passsed on from bobmsquare clicked() method
        b = board; /// the current board
        check(); ///initiates the check function 

    }

    public void check(){
        filename = new String[] {"images/0.png", "images/1.png", "images/2.png", "images/3.png", "images/4.png", "images/5.png", "images/6.png", "images/7.png", "images/8.png"};
		count = 0;                // used to keep track of surrounding bombs
        if(k.bomb()== true){
            b.getSquareAt((k.xLocation),(k.yLocation)).setImage("images/bomb.png"); ///if the square has a bomb sets the imaja to a picture of a bomb
        }

        else
		{


			///loops to check if any of the adjecent suqares touch a bomb
	         
	   		for(int i = -1; i<2; i++)
	        {

            	for(int j = -1; j<2; j++)
		    	{  
		        	BombSquare square = (BombSquare)b.getSquareAt((k.xLocation + i),(k.yLocation + j));
				  
	            	if(b.getSquareAt((k.xLocation + i),(k.yLocation + j)) != null && square.bomb() == true)
			    	{
			    		count++;
		        	}		
		        }
	        }

            b.getSquareAt((k.xLocation),(k.yLocation)).setImage(filename[count]); 
	        k.revealedtrue(); ///sets the current suqare as revealed this is important because when the function is called recursively it doesnt cover the same square 
            if(count ==0) ////this set of code runs if the square doesnt touch any mines i.e empty square
		    {

                for(int i = -1; i<=1; i++)
				{

                    for(int j = -1; j<=1; j++)
					///these loops allow [(-1,1 ),(0,1),(1,1)]     (X,X) is the current square and the for loops allow squares aroundcurrent suare to be checked()
					///                  [(-1,0 ),(X,X),(1,0)]
					///                  [(-1,-1),(0,-1),(1,-1)] 
		            {
						



		            	BombSquare r_square = (BombSquare)b.getSquareAt((k.xLocation + i),(k.yLocation + j));
	                	if( r_square!= null)
				    	{

						 	if(r_square.bomb() == false && r_square.reveal() == false )
					   		{
								r_square.clicked();                                                
			           		}                                                                     
		            	}	
		         	}
	            }
	 	
	        }
    
    

        }
    }
}