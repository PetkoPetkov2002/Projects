import javax.swing.*;
import javax.xml.crypto.dsig.keyinfo.RetrievalMethod;

import java.awt.*;
import java.util.*;

public class BombSquare extends GameSquare
{
	private int count;
	private String[] filename ;
	private boolean revealed = false;
	GameBoard g;
	private boolean thisSquareHasBomb = false;
	public static final int MINE_PROBABILITY = 10;

//	SmartSquare covers all the squares in blank 
	public BombSquare(int x, int y, GameBoard board)
	{
		super(x, y, "images/blank.png", board);        
		g = board;
		Random r = new Random();
		thisSquareHasBomb = (r.nextInt(MINE_PROBABILITY) == 0);
	}

	//  Checks Square for bomb and return true or false  
	public boolean bomb()
	{
        return(thisSquareHasBomb);	             
	}

	public void revealedfalse(){
		revealed = false;
		
	}

	public void revealedtrue(){
		revealed = true;
		
	}

	public boolean reveal(){
		return(revealed);
	}
	

	public void clicked()
	


	{ 
		///BombSquare r = (BombSquare) board.getSquareAt((xLocation),(yLocation));
		Checker ch = new Checker(this,g);
	}
}