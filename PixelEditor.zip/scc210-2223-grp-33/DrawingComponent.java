import java.io.*;
import java.util.Stack;
import java.awt.*;
/**
 * @author William Dove
 */
public abstract class DrawingComponent implements Cloneable, Serializable{

    //visible and selected are purely to assist at rendering currently and changes to their states should not be undoable/redoable 
    private Boolean visible = true; //this may be added to the undoable/redoable changes
    private Boolean selected = true;

    private Boolean deleted = true;//should be logged for undo/redo

    private DrawingModel model;

    protected Stack<Change> undoStack = new Stack<Change>();
    protected Stack<Change> redoStack = new Stack<Change>();

    /**
     * sets the basic state
     */
    public DrawingComponent(){
        undoStack.push(new Change(){public void apply(){setDeletedRaw(true);}});
        deleted=false;//the component is now being created so it is no longer "deleted"
    }

    /**
     * where showHintsIfSelected is true selected components will be drawn with hints
     * @param g the {@link Graphics2D} object to render changes on
     * @param showHintsIfSelected whether hints should be rendered
     */
    public abstract void render(Graphics2D g, Boolean showHintsIfSelected);

    /**
     * returns a boolean representing the visibility, true is visible, false is not visible
     * @return the visibility
     */
    public Boolean isVisible(){
        return this.visible;
    }

    /**
     * 
     * @param drawingModel the {@link DrawingModel} to be registered
     */
    public void registerModel(DrawingModel drawingModel){
        this.model = drawingModel;
    }

    /**
     * 
     * @param visibilty the visibility of the component
     */
    public void setVisible(Boolean visibilty){
        this.visible = visibilty;
    }

    /**
     * 
     * @return the new visibility
     */
    public Boolean toggleVisilbity(){
        this.visible=!this.visible;
        return this.visible;
    }

    /**
     * 
     * @return whether the component is selected
     */
    public Boolean isSelected(){
        return selected;
    }

    /**
     * 
     * @param selected sets whether the component is selected
     */
    public void setSelected(Boolean selected){
        this.selected = selected;
    }

    /**
     * toggles the state of selected
     * @return the new state of selected
     */
    public Boolean toggleSelected(){
        this.selected=!this.selected;
        return this.selected;
    }

    /**
     * 
     * @return wether the component is deleted
     */
    public Boolean isDeleted(){
        return this.deleted;
    }

    /**
     * sets wether the component has been deleted and updates the change management system
     * @param deleted wether the component has been deleted
     */
    public void setDeleted(Boolean deleted){
        this.deleted =deleted;
        componentAltered(new Change(){public void apply(){setDeletedRaw(deleted);}});
    }

    /**
     * sets wether the component has been deleted
     * @param deleted wether the component has been deleted
     */
    protected void setDeletedRaw(Boolean deleted){
        this.deleted = deleted;
    }
    
    public abstract Object clone() throws CloneNotSupportedException;

    /**
     * undos a change
     */
    public void undo(){
        if(undoStack.size()>1){
            Change change = undoStack.pop();
            redoStack.push(change);
        }
        rebuildState();
    }

    /**
     * rebuilds the state by applying all the changes, can be improved on.
     */
    private void rebuildState(){
        for(Change i: undoStack){
            i.apply();
        }
    }

    /**
     * redos a change
     */
    public void redo(){
        if(redoStack.size()>0){
            Change change = redoStack.pop();
            change.apply();
            undoStack.push(change);
        }
    }

    /**
     * updates the change management system with a change
     * @param c the change that has altered the component
     */
    public void componentAltered(Change c){
        model.registerUpdatedState(this);
        undoStack.push(c);
    }
}