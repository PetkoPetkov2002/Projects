import java.awt.*;
import java.awt.image.*;
import java.io.IOException;
import java.util.Stack;
import java.util.ArrayList;

/**
 * @author William Dove
 */
public class DrawingModel{
    private ArrayList<DrawingComponent> components = new ArrayList<DrawingComponent>();
    private DrawingComponent currentComponent = null;

    private Stack<DrawingComponent> undoStack = new Stack<DrawingComponent>();
    private Stack<DrawingComponent> redoStack = new Stack<DrawingComponent>();

    /**
     * creates a new DrawingModel
     */
    public DrawingModel(){}

    /**
     * creates a new drawing model from a set of components
     * @param components the components to initialise the model from
     */
    public DrawingModel(ArrayList<DrawingComponent> components){
        this.components = components; 
    }

    /**
     * returns the components which need rendering e.g not deleted and set to be visible
     * @return a list of components to be rendered
     */
    public ArrayList<DrawingComponent> getComponentsToRender(){
        ArrayList<DrawingComponent> comps = new ArrayList<DrawingComponent>();
        for(DrawingComponent i: components){
            if(i.isVisible() && !i.isDeleted()){
                comps.add(i);
            }
        }
        return comps;
    }

    /**
     * to be called by a {@link DrawingComponent} whenever its state is updated to ensure undo/redo functionality
     * @param c the {@link DrawingComponent} that called the method which wants to be added to the undoStack
     */
    public void registerUpdatedState(DrawingComponent c){
        undoStack.push(c);
        redoStack.clear();//clears the redo stack so changes cant be applied on top of the current image
    }

    /**
     * adds a new {@link DrawingComponent} to the model
     * @param c the {@link DrawingComponent} to be added
     */
    public void addComponent(DrawingComponent c){
        if(currentComponent!=null){//deselect the previous component
            currentComponent.setSelected(false);
        }
        components.add(c);
        currentComponent = c;
        undoStack.push(c);
        c.registerModel(this);
        redoStack.clear();//clears the redo stack so changes cant be applied on top of the current image
    }

    /**
     * returns the current (selected) component
     * @return one component which is selected
     */
    public DrawingComponent getCurrentComponent(){
        return currentComponent;
    }

    /**
     * sets the current component and deselects the previous one if it exists
     * @param c the component to be set
     */
    public void setCurrentComponent(DrawingComponent c){
        if(currentComponent!=null){//deselect the previous component
            currentComponent.setSelected(false);
        }
        currentComponent = c;
        currentComponent.setSelected(true);
    }

    /**
     * deselects the current component
     */
    public void deSelectComponent(){
        //System.out.println(currentComponent);
        if(currentComponent!=null){
            currentComponent.setSelected(false);
            currentComponent = null;
        }
    }

    /**
     * undos the most recent change
     */
    public void undo(){
        if(!undoStack.empty()){
            DrawingComponent c = undoStack.pop();
            c.undo();
            redoStack.push(c);
        }
    }

    /**
     * redo
     */
    public void redo(){
        if(!redoStack.empty()){
            DrawingComponent c = redoStack.pop();
            c.redo();
            undoStack.push(c);
        }
    }
}