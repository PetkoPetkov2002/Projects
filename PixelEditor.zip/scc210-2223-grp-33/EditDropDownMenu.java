import javax.swing.*;
import java.awt.event.*;

/**
 * The edit drop down menu
 */
class EditDropDownMenu extends JMenu{

    /**
     * creates an edit drop down menu
     * 
     * @param canvasManager
     */
    EditDropDownMenu(CanvasManager canvasManager){
        super("Edit");
        EditorMenuItem undo = new EditorMenuItem("Undo",KeyEvent.VK_Z); //items in Edit menu
        EditorMenuItem cut = new EditorMenuItem("Cut",KeyEvent.VK_X);
        EditorMenuItem copy = new EditorMenuItem("Copy",KeyEvent.VK_C);
        EditorMenuItem paste = new EditorMenuItem("Paste",KeyEvent.VK_V);
        EditorMenuItem redo = new EditorMenuItem("Redo",KeyEvent.VK_Y);
        JMenuItem copyArea = new JMenuItem("Select Area");
        JMenuItem pasteImage = new JMenuItem("Paste Image");
        add(undo); //add itmes into Edit menu
        undo.addActionListener(new ActionListener(){public void actionPerformed(ActionEvent e){canvasManager.getCurrentCanvas().undo();}});
        add(redo);
        redo.addActionListener(new ActionListener(){public void actionPerformed(ActionEvent e){canvasManager.getCurrentCanvas().redo();}});
        add(cut);
        cut.addActionListener(new ActionListener(){public void actionPerformed(ActionEvent e){canvasManager.cut();}});
        add(copy);
        copy.addActionListener(new ActionListener(){public void actionPerformed(ActionEvent e){canvasManager.copy();}});
        add(paste);
        paste.addActionListener(new ActionListener(){public void actionPerformed(ActionEvent e){canvasManager.paste();}});
        add(copyArea);
        copyArea.addActionListener(new ActionListener(){public void actionPerformed(ActionEvent e){canvasManager.getCurrentCanvas().setDrawingMode(14);;}});
        add(pasteImage);
        pasteImage.addActionListener(new ActionListener(){public void actionPerformed(ActionEvent e){canvasManager.getCurrentCanvas().setDrawingMode(15);;}});
    }
}