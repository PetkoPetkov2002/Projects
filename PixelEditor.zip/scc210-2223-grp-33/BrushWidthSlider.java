import javax.swing.JSlider;
import javax.swing.event.*;

/**
 * The brush width slider to adjust the width of the drawing tools
 * @author William Dove
 */
public class BrushWidthSlider extends JSlider implements ChangeListener{
    private static final int LOW = 1;
    private static final int HIGH = 50;
    private static final int INIT = 15;

    private CanvasManager canvasManager;

    /**
     * creates a new brush width slider
     * @param canvasManager the canvas manager it links to
     */
    public BrushWidthSlider(CanvasManager canvasManager){
        super(JSlider.HORIZONTAL,LOW, HIGH, INIT);
        setMajorTickSpacing(10);
        setMinorTickSpacing(1);
        setPaintTicks(true);
        setPaintLabels(true);
        this.canvasManager=canvasManager;
        addChangeListener(this);
    }

    /**
     * called when the state of the slider is updated
     */
    public void stateChanged(ChangeEvent e){
        canvasManager.getCurrentCanvas().setStrokeWidth(getValue());
    }
}