import javax.swing.*;
import javax.swing.event.ChangeListener;
import javax.swing.event.ChangeEvent;
class ImageTabs extends JTabbedPane{

    private Window w;
    private CanvasManager canvasManager;
    public ImageTabs(Window w,CanvasManager canvasManager){
        this.w = w;
        this.canvasManager = canvasManager;
        addChangeListener(changeListener);
    }

    public void addDrawingCanvas(CanvasWrapper wrapper){
        addTab(wrapper.getFileName(),wrapper.getDrawingCanvas());
    }

    ChangeListener changeListener = new ChangeListener() {
        public void stateChanged(ChangeEvent changeEvent) {
            JTabbedPane sourceTabbedPane = (JTabbedPane) changeEvent.getSource();
            int index = sourceTabbedPane.getSelectedIndex();
            DrawingCanvas c = (DrawingCanvas)getComponentAt(index);
            c.removeMouseListener(w);
            c.removeMouseMotionListener(w);
            canvasManager.setCurrentCanvas(c);
            c.addMouseListener(w);
            c.addMouseMotionListener(w);
        }
    };
}