
import java.awt.*;
import java.awt.image.*;
import java.io.*;

/**
 * @author William Dove
 */
public class ImageComponent extends DrawingComponent{
    private BufferedImage bufferedImage;

    /**
     * creates a new image component
     * @param b
     */
    public ImageComponent(BufferedImage b){
        super();
        this.bufferedImage=b;
        this.undoStack.push(new Change(){public void apply(){
            setDeleted(false);
        }});
    }

    /**
     * gets the buffered image held by this component
     * @return
     */
    public BufferedImage getBufferedImage(){
        return this.bufferedImage;
    }

    /**
     * 
     * @param g
     */
    public void render(Graphics2D g){
        g.drawImage(bufferedImage,null,0,0);
    }

    /**
     * renders the image
     */
    public void render(Graphics2D g, Boolean showHintsIfSelected){
        render(g);
    }

    /**
     * clones the component
     */
    public Object clone() throws CloneNotSupportedException{
        return new ImageComponent(bufferedImage);
    }
    
}