import java.awt.*;
import java.awt.geom.*;
import java.util.ArrayList;
/**
 * @author William Dove
 */
class CompositeShapeComponent extends DrawnComponent{
    private Stroke stroke;
    private ArrayList<Shape> shapes;
    private Color color;

    public CompositeShapeComponent(ArrayList<Shape> shapes, Stroke stroke, Color color){
        super();
        this.stroke=stroke;
        this.shapes=shapes;
        this.color=color;
        undoStack.push(new Change(){public void apply(){
            setDeletedRaw(false);
            setRawShapes(shapes);
            setRawStroke(stroke);
            setRawColor(color);}});
    }

    public ArrayList<Shape> getShapes(){
        return shapes;
    }

    public void setShape(ArrayList<Shape> shapes){
        this.shapes=shapes;
        componentAltered(new Change(){public void apply(){setRawShapes(shapes);}});
    }

    protected void setRawShapes(ArrayList<Shape> s){
        this.shapes = s;
    }

    private void renderShapes(Graphics2D g){
        if(stroke!=null){
            g.setStroke(stroke);
        }
        if(color!=null){
            g.setColor(color);
        }
        for(Shape shape: shapes){
            g.draw(shape);
        }
    }

    public void render(Graphics2D g, Boolean showHintsIfSelected){
        renderShapes(g);
    }

    public Object clone() throws CloneNotSupportedException{

        CompositeShapeComponent csc = new CompositeShapeComponent(shapes, stroke, color);//the shape also needs cloning
        return csc;
    }
}
