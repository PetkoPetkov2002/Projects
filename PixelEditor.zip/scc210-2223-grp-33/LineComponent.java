import java.awt.*;
import java.awt.image.*;
import java.io.File;
import java.io.IOException;
import java.util.Stack;
import java.util.ArrayList;
import java.util.LinkedList;
import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JPanel;
import java.io.*;
import javax.imageio.ImageIO;
import java.awt.geom.Line2D;

@Deprecated
class LineComponent extends DrawnComponent{
    private Stroke stroke = null;
    private LinkedList<Shape> components = new LinkedList<Shape>();
    private Color color = null;

    public LineComponent(Shape shape, Stroke stroke, Color color){
        super();
        this.stroke=stroke;
        this.components.push(shape);
        this.color=color;
        this.undoStack.push(new Change(){public void apply(){
            setDeleted(false);
        }});
    }

    public LineComponent(Stroke stroke, Color color){
        super();
        this.stroke=stroke;
        this.color=color;
        this.undoStack.push(new Change(){public void apply(){
            setDeleted(false);
        }});
    }


    public void addComponent(Shape shape){
        this.components.push(shape);
    }

    public LinkedList getComponents(){
        return this.components;
    }

    public void render(Graphics2D g){
        if(stroke!=null){
            g.setStroke(stroke);
        }
        if(color!=null){
            g.setColor(color);
        }
        for(Shape i: components){
            g.draw(i);
        }
    }

    public void render(Graphics2D g, Boolean showHintsIfSelected){
        render(g);
    }

    public Object clone() throws CloneNotSupportedException{
        LineComponent lc = new LineComponent(stroke, color);
        for(Shape i: components){
            lc.addComponent(i);
        }
        return lc;
    }
}