import javax.swing.*;  

class FilePopUpMenu extends JPopupMenu{
    public FilePopUpMenu(){
        JMenuItem close = new JMenuItem("close");
        add(close);
    }
}