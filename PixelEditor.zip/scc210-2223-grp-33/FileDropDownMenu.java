import javax.swing.*;
import javax.swing.filechooser.FileNameExtensionFilter;
import java.awt.event.*;

class FileDropDownMenu extends JMenu{

    public FileDropDownMenu(CanvasManager canvasManager, NewFileDialogue newFileDialogue,ImageTabs imageTabs){
        
        super("file");

        EditorMenuItem newFile = new EditorMenuItem("New File", KeyEvent.VK_N);
        EditorMenuItem openFile = new EditorMenuItem("Open File", KeyEvent.VK_O);
        EditorMenuItem exportImage = new EditorMenuItem("Export Image", KeyEvent.VK_S);
        JMenuItem saveFile = new JMenuItem("Save");
        JMenuItem saveFileAs = new JMenuItem("Save As");
        JMenuItem importImage = new JMenuItem("Import Image");
        JMenuItem help_button = new JMenuItem("Help");
        JLabel one = new JLabel("1.");
        JLabel cursor = new JLabel(new SizeableImageIcon("images/cursor.png",20,20));
        JLabel two = new JLabel(" 2.");
        JLabel eraser = new JLabel(new SizeableImageIcon("images/earser.png",20,20));
        
        JLabel three = new JLabel(" 3.");
        JLabel brush = new JLabel(new SizeableImageIcon("images/brush.png",20,20));
        JLabel four = new JLabel(" 4.");
        JLabel dropper = new JLabel(new SizeableImageIcon("images/dropper.png",20,20));
        JLabel five = new JLabel(" 5.");
        JLabel fill = new JLabel(new SizeableImageIcon("images/filltool.png",20,20));
        JLabel six = new JLabel(" 6.");
        JLabel pencil = new JLabel(new SizeableImageIcon("images/pencil.png",20,20));
        JLabel seven = new JLabel(" 7.");
        JLabel spray = new JLabel(new SizeableImageIcon("cursors/spray.png",20,20));

        JPanel panel = new JPanel();
        panel.add(one);
        panel.add(cursor);
        panel.add(two);
        panel.add(eraser);
        panel.add(three);
        panel.add(brush);
        panel.add(four);
        panel.add(dropper);
        panel.add(five);
        panel.add(fill);
        panel.add(six);
        panel.add(pencil);
        panel.add(seven);
        panel.add(spray);

        ActionListener importI = new ActionListener(){
            public void actionPerformed(ActionEvent e){
                JFrame parentFrame = new JFrame();
                JFileChooser fileChooser = new JFileChooser();
                FileNameExtensionFilter jpgFilter = new FileNameExtensionFilter("JPEG files", "jpg", "jpeg");
                FileNameExtensionFilter pngFilter = new FileNameExtensionFilter("png files", "png");
                fileChooser.addChoosableFileFilter(jpgFilter);
                fileChooser.addChoosableFileFilter(pngFilter);
                int userSelection = fileChooser.showOpenDialog(parentFrame);
                if(userSelection == JFileChooser.APPROVE_OPTION){
                    canvasManager.addCanvasWrapper(new CanvasWrapper(fileChooser.getSelectedFile(),"png"),true);
                    imageTabs.addDrawingCanvas(canvasManager.getCurrentCanvasWrapper());
                }
            }
        };

        ActionListener help = new ActionListener(){
            public void actionPerformed(ActionEvent e){
                Object[] message = {panel,"Here is some information on how to use our tools,all you have to do to use them is click the selected tool, you can also choose the colour from the colour picker:\n\n"
                +"Tool 1: this is our select tool, it allows you to resize shapes by clicking on them and dragging the mouse cursor\n\n"
                +"Tool 2: this is our eraser tool,it allows you to erase pixels off the screen just like using a rubber.\n\n"
                +"Tool 3: this is our paint brush,it allows you to draw pixels by dragging the mouse, yoiu can change the thickness of the brush by dragging the slider located above the tools bar\n\n"
                +"Tool 4: this is our drop tool,it allows you to extract the colour off the screen by clicking on it. Your tools will then paint with this colour\n\n"
                +"Tool 5: this is our fill tool,it allows you to fill in objects with the olour you have slected by clicking on them.\n\n"
                +"Tool 6: this is our pencil tool,it allows you to draw on the canvas by dragging the mouse, you cannot change the thickness of the line you draw with the slider\n\n"
                +"Tool 7: this is our spray tool,it allows you to draw a graffiti like spray on the canvas by dragging the mosue\n\n"};

                JOptionPane.showMessageDialog(help_button, message);
            }
        };

        ActionListener exportI = new ActionListener(){
            public void actionPerformed(ActionEvent e){
                JFrame parentFrame = new JFrame();
                JFileChooser fileChooser = new JFileChooser();
                FileNameExtensionFilter jpgFilter = new FileNameExtensionFilter("JPEG files", "jpg", "jpeg");
                FileNameExtensionFilter pngFilter = new FileNameExtensionFilter("png files", "png");
                fileChooser.addChoosableFileFilter(jpgFilter);
                fileChooser.addChoosableFileFilter(pngFilter);
                int userSelection = fileChooser.showSaveDialog(parentFrame);
                if(userSelection == JFileChooser.APPROVE_OPTION){
                    canvasManager.getCurrentCanvas().saveAsPNG(fileChooser.getSelectedFile());
                }
            }
        };

        ActionListener newF = new ActionListener(){
            public void actionPerformed(ActionEvent e){
                newFileDialogue.showFileDialogue();
            }
        };

        ActionListener saveF = new ActionListener(){
            public void actionPerformed(ActionEvent e){
                
            }};

        ActionListener saveAsF = new ActionListener(){
            public void actionPerformed(ActionEvent e){
                JFrame parentFrame = new JFrame();
                JFileChooser fileChooser = new JFileChooser();
                FileNameExtensionFilter jpgFilter = new FileNameExtensionFilter("JPEG files", "jpg", "jpeg");
                FileNameExtensionFilter pngFilter = new FileNameExtensionFilter("png files", "png");
                fileChooser.addChoosableFileFilter(jpgFilter);
                fileChooser.addChoosableFileFilter(pngFilter);
                int userSelection = fileChooser.showSaveDialog(parentFrame);
                if(userSelection == JFileChooser.APPROVE_OPTION){
                    canvasManager.getCurrentCanvas().saveState(fileChooser.getSelectedFile());
                }
            }
        };

        ActionListener openF = new ActionListener(){
            public void actionPerformed(ActionEvent e){
                JFrame parentFrame = new JFrame();
                JFileChooser fileChooser = new JFileChooser();
                FileNameExtensionFilter jpgFilter = new FileNameExtensionFilter("JPEG files", "jpg", "jpeg");
                FileNameExtensionFilter pngFilter = new FileNameExtensionFilter("png files", "png");
                fileChooser.addChoosableFileFilter(jpgFilter);
                fileChooser.addChoosableFileFilter(pngFilter);
                int userSelection = fileChooser.showOpenDialog(parentFrame);
                if(userSelection == JFileChooser.APPROVE_OPTION){
                    canvasManager.addCanvasWrapper(new CanvasWrapper(fileChooser.getSelectedFile(),""),true);
                    imageTabs.addDrawingCanvas(canvasManager.getCurrentCanvasWrapper());
                }
            }
        };
        help_button.addActionListener(help);
        newFile.addActionListener(newF);
        openFile.addActionListener(openF);
        saveFile.addActionListener(saveF);//disabled until fully implemented
        saveFileAs.addActionListener(saveAsF);
        exportImage.addActionListener(exportI);
        importImage.addActionListener(importI);

        add(newFile);
        add(new JSeparator());
        add(openFile);
        add(importImage);
        add(new JSeparator());
        add(saveFile);
        add(saveFileAs);
        add(new JSeparator());
        add(exportImage);
        add(help_button);
    }
}