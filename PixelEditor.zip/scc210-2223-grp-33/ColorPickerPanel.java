import java.awt.*;
import javax.swing.*;
import javax.swing.event.*;

/**
 * a panel holdoing the color picker
 */
public class ColorPickerPanel extends JPanel implements ChangeListener {
    private JColorChooser jColorChooser = new JColorChooser();
    private DrawingCanvas drawingCanvas;

    /**
     * 
     * @param drawingCanvas the canvas to set the color of
     */
    public ColorPickerPanel(DrawingCanvas drawingCanvas){
        this.drawingCanvas = drawingCanvas;
        jColorChooser.getSelectionModel().addChangeListener(this);
        add(jColorChooser,BorderLayout.PAGE_END);
        setOpaque(true);
    }

    /**
     * updates the color
     */
    public void stateChanged(ChangeEvent e)
	{
        drawingCanvas.setColor(jColorChooser.getColor());
	}
}