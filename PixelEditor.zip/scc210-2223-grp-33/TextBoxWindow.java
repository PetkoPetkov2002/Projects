import javax.swing.JFrame;

public class TextBoxWindow extends JFrame{
    private TextBoxPanel textBoxPanel;

    public TextBoxWindow(String title, DrawingCanvas drawingCanvas){
        super(title);
        textBoxPanel = new TextBoxPanel(drawingCanvas,this);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setContentPane(textBoxPanel);
        setSize(400, 100);
        setVisible(true);
    }
    
    public String getText() {
        return textBoxPanel.getText();
    }
}