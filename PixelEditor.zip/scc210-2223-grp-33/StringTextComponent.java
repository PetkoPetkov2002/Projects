import java.awt.*;
import javax.swing.JTextArea;

/**
 * @author William Dove
 */
public class StringTextComponent extends DrawingComponent{

    private String text;
    private int x;
    private int y;
    private Font font;
    private Color color;

    /**
     * creates a new StringTextComponent
     * @param text the text the component will hold
     * @param x the x coordinate
     * @param y the y coordiante
     * @param font the font of the text
     * @param color the color of the text
     */
    public StringTextComponent(String text, int x, int y, Font font, Color color){
        super();
        this.text = text;
        this.x = x;
        this.y = y;
        this.font = font;
        this.color=color;
        undoStack.push(new Change(){public void apply(){
            setDeleted(false);
            setText(text);
            setPosition(x,y);
            setFont(font);
            setColor(color);
        }});
    }

    /**
     * 
     * @return the text String
     */
    public String getText(){
        return this.text;
    }

    /**
     * sets the text
     * @param text the string to be set
     */
    public void setText(String text){
        this.text = text;
    }

    /**
     * sets the font
     * @param f the font to be set
     */
    public void setFont(Font f){
        this.font = f;
    }

    /**
     * sets the color
     * @param c the color to be set
     */
    public void setColor(Color c){
        this.color = c;
    }

    /**
     * 
     * @param x the x coordinate
     * @param y the y coordinate
     */
    public void setPosition(int x, int y){
        this.x=x;
        this.y=y;
    }

    /**
     * 
     * @param x the x coordinate
     */
    public void setXPosition(int x){
        this.x=x;
    }

    /**
     * 
     * @param y the y coordinate
     */
    public void setYPosition(int y){
        this.y=y;
    }

    /**
     * 
     * @return the x coordinate
     */
    public int getXPosition(){
        return this.x;
    }

    /**
     * 
     * @return the y coordinate
     */
    public int getYPosition(){
        return this.y;
    }

    /**
     * renders the text
     * @param g the graphics to render onto
     * @param showHintsIfSelected shows the hints for drawing
     */
    public void render(Graphics2D g, Boolean showHintsIfSelected){
        if(font!=null){
            g.setFont(font);
        }else{
            g.setFont(new Font("Courier",Font.PLAIN,20));
        }

        if(showHintsIfSelected && isSelected()){
            g.setColor(Color.BLACK);
            g.setStroke(new MarkingStroke());
            int length = text.length();
            if(text == null || text ==""){
                g.drawString("Your Text Here",x,y);
                length=14;
            }
            g.drawRect(x-1,y-20,12*length,30);
        }

        g.setColor(color);
        if(font!=null){
            g.setFont(font);
        }else{
            g.setFont(new Font("Courier",Font.PLAIN,20));
        }
        g.drawString(text,x,y);
    }


    /**
     * clones the object
     */
    public Object clone() throws CloneNotSupportedException{
        StringTextComponent stc = new StringTextComponent(text, x, y, font, color);
        return stc;
    }
}