import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
class NewFileDialogue extends JDialog{

    private JTextField widthInput = new JTextField("600",4);
    private JTextField heightInput = new JTextField("600",4);
    private JTextField nameInput = new JTextField("untitled",20);
    private JLabel widthLabel = new JLabel("width:");
    private JLabel heightLabel = new JLabel("height:");
    private JLabel nameLabel = new JLabel("name:");
    private JButton acceptButton = new JButton("Ok");
    private JButton cancelButton = new JButton("Cancel");

    public NewFileDialogue(Frame owner){
        super(owner,"New File", true);
        init();
        acceptButton.addActionListener(new ActionListener(){
            public void actionPerformed(ActionEvent e){
                dispose();
            }
        });
    }

    public NewFileDialogue(Frame owner,ActionListener a){
        super(owner,"New File", true);
        init();
        acceptButton.addActionListener(a);
    }

    private void init(){
        setSize(230,150);
        setLayout(new FlowLayout());
        add(widthLabel);
        add(widthInput);
        add(heightLabel);
        add(heightInput);
        add(nameLabel);
        add(nameInput);
        add(cancelButton);
        add(acceptButton);
        cancelButton.addActionListener(new ActionListener(){
            public void actionPerformed(ActionEvent e){
                dispose();
            }
        });
    }

    public void showFileDialogue(){
        setVisible(true);    
    }

    public String getCanvasWidth(){
        
        return widthInput.getText();
    }

    public String getCanvasHeight(){
        return heightInput.getText();
    }

    public String getFileName(){
        return nameInput.getText();
    } 
}