import javax.swing.JFrame;

public class ColorPickerWindow extends JFrame{
    private ColorPickerPanel colorPickerPanel;

    public ColorPickerWindow(String title, DrawingCanvas drawingCanvas){
        super(title);
        this.colorPickerPanel = new ColorPickerPanel(drawingCanvas);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setContentPane(colorPickerPanel);
        pack();
    }
}