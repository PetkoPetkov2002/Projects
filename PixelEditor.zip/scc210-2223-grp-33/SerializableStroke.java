import java.awt.*;
import java.io.*;

class SerializableStroke extends BasicStroke implements Serializable{
    
}