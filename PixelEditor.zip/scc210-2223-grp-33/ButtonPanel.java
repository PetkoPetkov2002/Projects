import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

class ButtonPanel extends JPanel{

    public ButtonPanel(CanvasManager canvasManager){
        setLayout(new FlowLayout(FlowLayout.LEFT));

        ActionListener penActionListener = new ActionListener(){
            public void actionPerformed(ActionEvent e){
                canvasManager.getCurrentCanvas().setDrawingMode(1);
            }
        };

        ActionListener brushActionListener = new ActionListener(){
            public void actionPerformed(ActionEvent e){
                canvasManager.getCurrentCanvas().setDrawingMode(2);
            }
        };

        ActionListener eraserActionListener = new ActionListener(){
            public void actionPerformed(ActionEvent e){
                canvasManager.getCurrentCanvas().setDrawingMode(0);
            }
        };

        ActionListener colorActionListener = new ActionListener(){
            public void actionPerformed(ActionEvent e){
                ColorPickerWindow colorPickerWindow = new ColorPickerWindow(" Colour Picker", canvasManager.getCurrentCanvas());
                colorPickerWindow.setVisible(true);
            }
        };

        ActionListener selectActionListener = new ActionListener(){//not yet implemented
            public void actionPerformed(ActionEvent e){
                canvasManager.getCurrentCanvas().setDrawingMode(-1);
            }
        };
                
        ActionListener FillActionListener = new ActionListener(){
            public void actionPerformed(ActionEvent e){
                canvasManager.getCurrentCanvas().setDrawingMode(6);
            }
        };

        ActionListener eyeDroppListener = new ActionListener()
        {
            public void actionPerformed(ActionEvent e)
            {
                canvasManager.getCurrentCanvas().setDrawingMode(10);
            }

        };

        ActionListener sprayActionListener = new ActionListener(){
            public void actionPerformed(ActionEvent e){
                canvasManager.getCurrentCanvas().setDrawingMode(13);
            }
        };
        
        JButton Spray = new JButton("Spray", new SizeableImageIcon("cursors/spray.png",30,30));
        Spray.setVerticalTextPosition(SwingConstants.BOTTOM);
        Spray.setHorizontalTextPosition(SwingConstants.CENTER);


        JButton Pen = new JButton("Pen", new ImageIcon("images/pencil.png"));
        Pen.setVerticalTextPosition(SwingConstants.BOTTOM);
        Pen.setHorizontalTextPosition(SwingConstants.CENTER);

        JButton Eraser = new JButton("Eraser",new ImageIcon("images/earser.png"));
        Eraser.setVerticalTextPosition(SwingConstants.BOTTOM);
        Eraser.setHorizontalTextPosition(SwingConstants.CENTER);

        JButton Brush = new JButton("Brush", new ImageIcon("images/brush.png"));
        Brush.setVerticalTextPosition(SwingConstants.BOTTOM);
        Brush.setHorizontalTextPosition(SwingConstants.CENTER);
        
        JButton Colors = new JButton("Colors", new ImageIcon("images/color.png"));
        Colors.setVerticalTextPosition(SwingConstants.BOTTOM);
        Colors.setHorizontalTextPosition(SwingConstants.CENTER);

        JButton Select = new JButton("Select", new SizeableImageIcon("images/cursor.png",30,30));
        Select.setVerticalTextPosition(SwingConstants.BOTTOM);
        Select.setHorizontalTextPosition(SwingConstants.CENTER);

        JButton Fill = new JButton("Fill", new ImageIcon("images/filltool.png"));
        Fill.setVerticalTextPosition(SwingConstants.BOTTOM);
        Fill.setHorizontalTextPosition(SwingConstants.CENTER);

        JButton EyeDropper = new JButton("Eye Dropper",new SizeableImageIcon("images/dropper.png",30,30) );
        EyeDropper.setVerticalTextPosition(SwingConstants.BOTTOM);
        EyeDropper.setHorizontalTextPosition(SwingConstants.CENTER);
        



        add(Pen); //add buttons into bottom panel
        Pen.setPreferredSize(new Dimension(100, 60));
        Pen.addActionListener(penActionListener);
        
        add(Brush);
        Brush.setPreferredSize(new Dimension(100, 60));
        Brush.addActionListener(brushActionListener);

        add(Eraser);
        Eraser.setPreferredSize(new Dimension(100, 60));
        Eraser.addActionListener(eraserActionListener);

        add(Fill);
        Fill.setPreferredSize(new Dimension(100, 60));
        Fill.addActionListener(FillActionListener);
        
        add(Colors);
        Colors.setPreferredSize(new Dimension(100, 60));
        Colors.addActionListener(colorActionListener);

        add(Select);
        Select.setPreferredSize(new Dimension(100, 60));
        Select.addActionListener(selectActionListener);

        add(EyeDropper);
        EyeDropper.setPreferredSize(new Dimension(100,60));
        EyeDropper.addActionListener(eyeDroppListener);

        
        add(Spray);
        Spray.setPreferredSize(new Dimension(100,60));
        Spray.addActionListener(sprayActionListener);
    }
}