import java.awt.*;

class MarkingStroke extends BasicStroke{
    private final static float dash[] = {10f};

    public MarkingStroke(){
        super(1f,BasicStroke.CAP_BUTT,BasicStroke.JOIN_MITER,10f,dash,0f);
    }
}