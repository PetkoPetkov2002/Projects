import java.awt.*;

/**
 * @author William Dove
 */
public abstract class DrawnComponent extends DrawingComponent{

    protected Stroke stroke;
    protected Color color;

    /**
     * gets the stroke
     * @return the stroke
     */
    public Stroke getStroke(){
        return this.stroke;
    }

    /**
     * sets the stroke
     * @param stroke the stroke to be set
     */
    public void setStroke(Stroke stroke){
        this.stroke = stroke;
        componentAltered(new Change(){public void apply(){setRawStroke(stroke);}});

    }

    /**
     * gets the color of this component
     * @return the color
     */
    public Color getColor(){
        return this.color;
    }

    /**
     * sets the color of this component
     * @param color the color 
     */
    public void setColor(Color color){
        this.color = color;
        componentAltered(new Change(){public void apply(){setRawColor(color);}});
    }

    /**
     * directly sets the stroke, does not create a change
     * @param s the stroke to be set
     */
    protected void setRawStroke(Stroke s){
        this.stroke = s;
    }

    /**
     * directly sets the color, does not create a change
     * @param c the color
     */
    protected void setRawColor(Color c){
        this.color = c;
    }

}