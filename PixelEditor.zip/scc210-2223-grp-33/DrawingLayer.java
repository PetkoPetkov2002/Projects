class DrawingLayer{

    private Boolean visible = true;
    
    public Boolean isVisible(){
        return this.visible;
    }

    public void setVisible(Boolean visibilty){
        this.visible = visibilty;
    }

    public void toggleVisilbity(){
        this.visible=!this.visible;
    }

}