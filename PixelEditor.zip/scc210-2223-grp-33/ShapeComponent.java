import java.awt.*;
import java.awt.geom.*;
/**
 * @author William Dove
 */
class ShapeComponent extends DrawnComponent{
    private Stroke stroke;
    private Shape shape;
    private Color color;

    /**
     * creates a new ShapeComponent
     * @param shape the shape to set
     * @param stroke the stroke to set
     * @param color the color to set
     */
    public ShapeComponent(Shape shape, Stroke stroke, Color color){
        super();
        this.stroke=stroke;
        this.shape=shape;
        this.color=color;
        undoStack.push(new Change(){public void apply(){
            setDeletedRaw(false);
            setRawShape(shape);
            setRawStroke(stroke);
            setRawColor(color);}});
    }

    /**
     * returns the shape
     * @return the shape
     */
    public Shape getShape(){
        return shape;
    }

    /**
     * sets the shape, updates the change management system
     * @param shape the shape to set
     */
    public void setShape(Shape shape){
        this.shape=shape;
        componentAltered(new Change(){public void apply(){setRawShape(shape);}});
    }

    /**
     * sets the shape, does not update the change management system
     * @param s the shape to beset
     */
    protected void setRawShape(Shape s){
        this.shape = s;
    }

    private void renderShape(Graphics2D g){
        if(stroke!=null){
            g.setStroke(stroke);
        }
        if(color!=null){
            g.setColor(color);
        }
        g.draw(shape);
    }

    public void render(Graphics2D g, Boolean showHintsIfSelected){
        renderShape(g);
        //System.out.println("selected: " + isSelected());
        if(showHintsIfSelected && isSelected() && !(shape instanceof Path2D)){//a bounding box should not be drawn for paths
            Rectangle2D b = shape.getBounds2D();
            g.setColor(Color.BLUE);
            g.setStroke(new MarkingStroke());
            g.draw(b);
            g.fillRect((int)(b.getX()-10), (int)(b.getY()-10), 20, 20);
            g.fillRect((int)(b.getX()-10), (int)(b.getY()+b.getHeight()-10), 20, 20);
            g.fillRect((int)(b.getX()+b.getWidth()-10), (int)(b.getY()-10), 20, 20);
            g.fillRect((int)(b.getX()+b.getWidth()-10), (int)(b.getY()+b.getHeight()-10), 20, 20);
        }
    }

    /**
     * clones the shape component
     * @return a deep copy of the shape component
     */
    public Object clone() throws CloneNotSupportedException{
        
        //System.out.println(shape.getClass());
        Shape s;
        if(this.shape instanceof Polygon){
            s = this.shape;
        }else if(this.shape instanceof RectangularShape){
            s = (Shape)((RectangularShape)this.shape).clone();
        }else if(this.shape instanceof Ellipse2D){
            s = (Shape)((Ellipse2D)this.shape).clone();
        }else{
            s = this.shape;
        }
        ShapeComponent sc = new ShapeComponent(s, stroke, color);//the shape also needs cloning
        return sc;
    }
}
