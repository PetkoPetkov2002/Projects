/**
 * represents a change
 */
interface Change{

    /**
     * called to apply the change
     */
    public void apply();
    
}