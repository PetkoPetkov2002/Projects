import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class TextBoxPanel extends JPanel{

    private DrawingCanvas drawingCanvas;
    private JLabel textBox;
    private JTextField inputField;
    private JButton addButton;

    public TextBoxPanel(DrawingCanvas drawingCanvas,JFrame window){
        this.drawingCanvas = drawingCanvas;

        // Initialize label and text field
        textBox = new JLabel("Add text: max input length is 30");
        inputField = new JTextField(30);

        // Initialize add button and add action listener
        addButton = new JButton("Add");
        addButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String text = inputField.getText();
                if (text.length() > 30) 
                {
                    JOptionPane.showMessageDialog(TextBoxPanel.this, "Input exceeds 30 characters.", "Error", JOptionPane.ERROR_MESSAGE);
                } 
                else if (text.length() == 0) 
                {
                    JOptionPane.showMessageDialog(TextBoxPanel.this, "Please enter text.", "Error", JOptionPane.ERROR_MESSAGE);
                } 
                else 
                {
                    drawingCanvas.setTextComponentString(text);
                    if (window != null) {
                        window.dispose();
                    }
                }
            }
        });

        // Set layout to BoxLayout and set alignment to top
        setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));
        // Add components to panel
        add(textBox);
        add(inputField);
        add(addButton);
        setOpaque(true);
    }
    
    public String getText() {
        return inputField.getText();
    }
}