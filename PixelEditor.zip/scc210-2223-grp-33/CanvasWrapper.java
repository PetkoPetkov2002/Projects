import java.io.File;

class CanvasWrapper{

    private String fileName;
    private DrawingCanvas drawingCanvas;


    public CanvasWrapper(){
        this.drawingCanvas = new DrawingCanvas(600,600);
    }

    public CanvasWrapper(String fileName){
        this.fileName = fileName;
        this.drawingCanvas = new DrawingCanvas(600,600);
    }

    public CanvasWrapper(String fileName, int width, int height){
        this.fileName = fileName;
        this.drawingCanvas = new DrawingCanvas(width,height);
        System.out.println("creating canvas of: "+width+"x"+height);
    }

    public CanvasWrapper(File file, String type){
        this.fileName = file.getName();
        this.drawingCanvas = new DrawingCanvas(file,type);
    }


    public String getFileName(){
        return this.fileName;
    }

    public DrawingCanvas getDrawingCanvas(){
        return this.drawingCanvas;
    }
}