import javax.swing.*;

public class SizeableImageIcon extends ImageIcon{
    public SizeableImageIcon(String path, int x, int y){
        super(new ImageIcon(path).getImage().getScaledInstance(x, y,  java.awt.Image.SCALE_SMOOTH));
    }
}