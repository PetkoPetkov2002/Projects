import javax.swing.*;
import java.awt.event.*;

class EditorMenuItem extends JMenuItem{

    public EditorMenuItem(String text, int shortCut){
        super(text,shortCut);
        setAccelerator(KeyStroke.getKeyStroke(shortCut, ActionEvent.CTRL_MASK));
    }
}