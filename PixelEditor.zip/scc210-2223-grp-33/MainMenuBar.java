import javax.swing.*;

class MainMenuBar extends JMenuBar{

    public MainMenuBar(CanvasManager canvasManager,NewFileDialogue newFileDialogue, ImageTabs imageTabs)
    {                
        add(new FileDropDownMenu(canvasManager,newFileDialogue,imageTabs)); //add menus into menu bar
        add(new EditDropDownMenu(canvasManager));
        add(new InsertDropDownMenu(canvasManager));
    }
}
