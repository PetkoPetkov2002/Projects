import java.util.ArrayList;

/**
 * stores the canvases, provides the ability to alter which canvas tools etc are pointed at
 * @author William Dove
 */
public class CanvasManager{
    private ArrayList<CanvasWrapper> files = new ArrayList<CanvasWrapper>();
    private int currentCanvasIndex;

    private DrawingComponent clipBoard = null;

    /**
     * 
     * @param cw the canvas wrapper to add
     * @param updatePosition whether the position should be updated to reflect the added canvas
     */
    public void addCanvasWrapper(CanvasWrapper cw,Boolean updatePosition){
        files.add(cw);
        if(updatePosition){
            currentCanvasIndex = files.size()-1;
        }
    }

    /**
     * @return the current CanvasWrapper
     */
    public CanvasWrapper getCurrentCanvasWrapper(){
        return files.get(currentCanvasIndex);
    }

    /**
     * @return the current Canvas
     */
    public DrawingCanvas getCurrentCanvas(){
        return files.get(currentCanvasIndex).getDrawingCanvas();
    }

    /**
     * sets the current canvas
     * @param i the index of the canvas
     */
    public void setCurrentCanvas(int i){
        currentCanvasIndex=i;
    }

    /**
     * sets the current canvas
     * @param c the canvas to set the position to
     */
    public void setCurrentCanvas(DrawingCanvas c){
        for(int i = 0; i<files.size();i++){
            if(files.get(i).getDrawingCanvas()==c){
                currentCanvasIndex=i;
                break;
            }
        }
    }

    /**
     * sets the value of the clipboard
     * @param c
     */
    public void setClipBoard(DrawingComponent c){
        this.clipBoard = c;
    }

    /**
     * gets the the clipboard
     * @return
     */
    public DrawingComponent getClipBoard(){
        return this.clipBoard;
    }

    /**
     * copies from the current canvas
     */
    public void copy(){
        clipBoard = getCurrentCanvas().copy();
    }

    /**
     * cuts from the current canvas
     */
    public void cut(){
        clipBoard = getCurrentCanvas().cut();
    }

    /**
     * pastes from the current canvas
     */
    public void paste(){
        getCurrentCanvas().paste(clipBoard);
    }
}