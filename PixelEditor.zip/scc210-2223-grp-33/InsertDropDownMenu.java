import javax.swing.*;
import javax.swing.filechooser.FileNameExtensionFilter;

import java.awt.event.*;

class InsertDropDownMenu extends JMenu{

    private JMenuItem textBox = new JMenuItem("Text box"); //items in Insert
    private JMenu shapes = new JMenu("Shapes");
    private JMenuItem images = new JMenuItem("Images");
    private JMenuItem arror = new JMenuItem(new SizeableImageIcon("images/arrow.png",30,30)); //different shapes
    private JMenuItem rectangle = new JMenuItem(new SizeableImageIcon("images/rectangle.png",30,30));
    private JMenuItem circle = new JMenuItem(new SizeableImageIcon("images/circle.png",30,30));
    private JMenuItem straightLine = new JMenuItem(new SizeableImageIcon("images/straight_line.png",30,30));
    private JMenuItem triangle = new JMenuItem(new SizeableImageIcon("images/triangle.png",30,30));
    private JMenuItem star = new JMenuItem(new SizeableImageIcon("images/star.png",30,30));

    public InsertDropDownMenu(){
        super("Insert");
        add(textBox); // add items into Insert menu
        add(shapes);
        add(images);
        shapes.add(arror); //add shapes 
        shapes.add(rectangle);
        shapes.add(circle);
        shapes.add(straightLine);
        shapes.add(triangle);
        shapes.add(star);
    }

    public InsertDropDownMenu(CanvasManager canvasManager){
        super("Insert");
        textBox.addActionListener(new ActionListener(){public void actionPerformed(ActionEvent e){}});
        rectangle.addActionListener(new ActionListener(){public void actionPerformed(ActionEvent e){canvasManager.getCurrentCanvas().setDrawingMode(3);}});
        star.addActionListener(new ActionListener(){public void actionPerformed(ActionEvent e){canvasManager.getCurrentCanvas().setDrawingMode(4);}});
        circle.addActionListener(new ActionListener(){public void actionPerformed(ActionEvent e){canvasManager.getCurrentCanvas().setDrawingMode(5);}});
        triangle.addActionListener(new ActionListener(){public void actionPerformed(ActionEvent e){canvasManager.getCurrentCanvas().setDrawingMode(7);}});
        arror.addActionListener(new ActionListener(){public void actionPerformed(ActionEvent e){canvasManager.getCurrentCanvas().setDrawingMode(8);}});
        straightLine.addActionListener(new ActionListener(){public void actionPerformed(ActionEvent e){canvasManager.getCurrentCanvas().setDrawingMode(9);}});
        textBox.addActionListener(new ActionListener(){public void actionPerformed(ActionEvent e){canvasManager.getCurrentCanvas().setDrawingMode(11);}});
        
        
        images.addActionListener(new ActionListener(){public void actionPerformed(ActionEvent e){
            JFrame parentFrame = new JFrame();
            JFileChooser fileChooser = new JFileChooser();
            FileNameExtensionFilter jpgFilter = new FileNameExtensionFilter("JPEG files", "jpg", "jpeg");
            FileNameExtensionFilter pngFilter = new FileNameExtensionFilter("png files", "png");
            fileChooser.addChoosableFileFilter(jpgFilter);
            fileChooser.addChoosableFileFilter(pngFilter);
            int userSelection = fileChooser.showOpenDialog(parentFrame);
            if(userSelection == JFileChooser.APPROVE_OPTION){
                canvasManager.getCurrentCanvas().importImage(fileChooser.getSelectedFile());
            }}});

        add(textBox); // add items into Insert menu
        add(shapes);
        add(images);
        shapes.add(arror); //add shapes 
        shapes.add(rectangle);
        shapes.add(circle);
        shapes.add(straightLine);
        shapes.add(triangle);
        shapes.add(star);
    }
}