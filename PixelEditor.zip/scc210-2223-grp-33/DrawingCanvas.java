import java.awt.*;
import java.awt.image.*;
import java.awt.event.*;
import java.io.File;
import java.io.IOException;
import java.util.*;
import javax.imageio.ImageIO;
import javax.swing.JPanel;
import java.io.*;
import java.lang.Integer;
import java.awt.geom.*;
import java.awt.geom.AffineTransform;

public class DrawingCanvas extends JPanel implements MouseWheelListener{

    private Color color = Color.BLACK;
    private Color bkgdColor = Color.WHITE;
    private boolean firstDrag = true;
    private int drawingMode = 1;     //0:erase     1:pen     2:brush
    private int prevX,prevY;
    private float strokeWidth = 20f;

    private double zoomLevel = 1.0;

    private DrawingModel drawingModel = new DrawingModel();
    private BufferedImage selecetedArea;

    public DrawingCanvas() {}

    public DrawingCanvas(int width, int height){
        setSize(width,height);
        this.requestFocus();
        this.addMouseWheelListener(this);
    }

    /**
     * 
     * @param file the file to read from
     * @param type the type of file to decide whether it should be loaded as a png or serialised object
     */
    public DrawingCanvas(File file,String type){
        if(type=="png"){//code for reading an image file
            try{
                drawingModel.addComponent(new ImageComponent(ImageIO.read(file)));
                
            }catch(Exception e){}
        }else{//code for reading a serialised object
            try{
                FileInputStream fileIn = new FileInputStream(file);
                ObjectInputStream in = new ObjectInputStream(fileIn);
                drawingModel = new DrawingModel((ArrayList<DrawingComponent>)in.readObject());
                in.close();
                fileIn.close();
            }catch(Exception ex){
                System.out.println("IOException is caught");
            }
        }
        setSize(600,600);
        
    }

    public void mouseWheelMoved(MouseWheelEvent e){
        int scrollAmount = e.getWheelRotation();
        if(scrollAmount<0){
            zoomLevel+=0.2;
            if(zoomLevel>6.0){
                zoomLevel = 6.0; 
            }
        }
        else if(scrollAmount>0){
            zoomLevel -= 0.4;
            if(zoomLevel<1){
                zoomLevel = 1.0; 
            }
        }
        repaint();
    }

    private void zoom(Graphics2D g){
        if(zoomLevel>1){
            AffineTransform at = new AffineTransform();
            at.scale(zoomLevel,zoomLevel);
            g.transform(at);
        }
    }

    private void render(Graphics2D g, Boolean showMarkings){
        g.setColor(bkgdColor);
        g.fillRect ( 0, 0, getWidth(), getHeight());
        for(DrawingComponent i: drawingModel.getComponentsToRender()){
            i.render(g,showMarkings);
        }
    }

    @Override
    public void paintComponent(Graphics g) {
        Graphics2D g2d =(Graphics2D)g;
        this.zoom(g2d);
        this.render(g2d,true);
    }

    //set color of pen/brush
    public void setColor(Color c) {
        color = c;
    }

    public void setStrokeWidth(float width){
        this.strokeWidth=width;
    }

    /**
     * sets the cursor image
     * @param mode the cursor mode
     */
    public void setCursorinCanvas(int mode){
        String fileName = "null";
        switch (mode) {
            case -1:
                //System.out.println("-1");
                //select
                fileName = "./cursors/cursor.png";
                break;
            case 0:
                //System.out.println("0");
                //eraser
                fileName = "./cursors/eraser.png";
                break;
            case 1:
                //System.out.println("1");
                //pen
                fileName = "./cursors/pen.png";
                break;
            case 2:
                //System.out.println("2");
                //brush
                fileName = "./cursors/brush.png";
                break;
            case 6:
                //System.out.println("6");
                //fill
                //fileName = "./cursors/fill.png";
                break;
            case 10:
                //System.out.println("10");
                fileName = "./cursors/dropper.png";
                break;
            case 61:
                //System.out.println("61");    
                //loading
                fileName = "./cursors/loading.png";
                break;
        
            default:

                break;
        }

        if (fileName != "null"){
            setCursor(Toolkit.getDefaultToolkit().createCustomCursor(
            new SizeableImageIcon(fileName,30,30).getImage(),
            new Point(0,0),"custom cursor"));
        }else{
            setCursor(Cursor.getDefaultCursor());
        }
    }

    /**
     * 
     * @return the drawing mode
     */
    public int getDrawingMode(){
        return drawingMode;
    }

    /**
     * Sets the drawing mode
     * @param mode the drawing mode to set
     */
    public void setDrawingMode(int mode){
        this.drawingMode = mode;
        //System.out.println(mode);
        setCursorinCanvas(mode);
    }

    /**
     * Sets the previous coordinates
     * @param pX the previous X coordinate
     * @param pY the previous Y coordinate
     */
    public void setPrev(int pX, int pY){
        prevX = pX;
        prevY = pY;
    }

    /**
     * reset previous coordinates( to -ve so its invalid)
     */
    public void resetPrev(){
        prevX = -1;
        prevY = -1;
    }

    /**
     * call different draw methods depending on drawing mode
     * @param x
     * @param y
     */
    public void draw(int x, int y, Boolean finalDrawing){
        
        //adjusts the values to account for the zoom
        x = (int)(x/zoomLevel);
        y = (int)(y/zoomLevel);

        if(prevX <= 0){
            prevX = x;
        }
        if(prevY <=0){
            prevY = y;
        }
        switch (drawingMode) {
            case -5:
                resizeLine(x, y, finalDrawing);
                break;
            case -4:
                resizeOval(x,y,finalDrawing);
                break;
            case -3:
                resizePolygon(x, y, finalDrawing);
                break;
            case -2:
                resizeRectangle(x, y, finalDrawing);
                break;
            case -1:
                select(x,y);
                break;
            case 0:
                erase(x, y, finalDrawing);
                break;
            case 1:
                penDraw(x, y, finalDrawing);
                break;
            case 2:
                brushDraw(x, y, finalDrawing);
                break;
            case 3 :
                drawRectangle(x, y, finalDrawing);
                break;
            case 4:
                drawStar(x, y, finalDrawing);
                break;
            case 5:
                drawOval(x, y, finalDrawing);
                break;
            case 6:
                fillTool(x, y);
                break;
            case 7:
                drawTriangle(x,y,finalDrawing);
                break;
            case 8:
                drawArror(x,y,finalDrawing);
                break;
            case 9:
                drawStraightLine(x,y,finalDrawing);
                break;
            case 10:
                eyeDropper(x, y);
                break;
            case 11:
                textBox(x,y,finalDrawing);
                break;
            case 13:
                sprayDraw(x,y,finalDrawing);
                break;
            case 14:
                areaSelect(x, y, finalDrawing);
                break;
            case 15:
                pasteImage(x, y,finalDrawing);
                break;
            default:
                break;
        }
    }

    private void sprayDraw(int x, int y, boolean finalDrawing){
        ArrayList<Shape> shapes = new ArrayList<Shape>();
        for(int i = x - 10; i < x + 10; i++) { 
            for(int j = y - 10; j < y + 10; j++) {
                Random random = new Random();
                // Create a random point in the given spray radius 
                int xPos = random.nextInt(2*10) - 10; 
                int yPos = random.nextInt(2*10) - 10; 
                // Draw a circle with the given color at the random point 
                Ellipse2D circle = new Ellipse2D.Double(i + xPos, j + yPos, 2, 2);
                shapes.add(circle);
            }
        }
        drawingModel.addComponent(new CompositeShapeComponent(shapes,new BasicStroke(1f,BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND),color));
        repaint();
    }

    /**
     * pen draw
     */
    private void penDraw(int x, int y,Boolean finalDrawing){
       
        if(firstDrag){
            Path2D.Float p = new Path2D.Float();
            p.moveTo(x, y);
            drawingModel.addComponent(new ShapeComponent(p,new BasicStroke(1f,BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND),color));
            firstDrag = false;
        }else{   
            ((Path2D)((ShapeComponent)drawingModel.getCurrentComponent()).getShape()).lineTo(x, y);
        }
        setPrev(x,y);
        repaint();
        if(finalDrawing){
            firstDrag = true;
        }
    }

    

    /**
     * brush draw
     */
    private void brushDraw(int x, int y,Boolean finalDrawing){
        if(firstDrag){
            Path2D.Float p = new Path2D.Float();
            p.moveTo(x, y);
            drawingModel.addComponent(new ShapeComponent(p,new BasicStroke(strokeWidth,BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND),color));
            firstDrag = false;
        }else{
            ((Path2D)((ShapeComponent)drawingModel.getCurrentComponent()).getShape()).lineTo(x, y);
        }
        setPrev(x,y);
        repaint();
        if(finalDrawing){
            firstDrag = true;
        }
    }

    /**
     * Draws a rectangle
     * @param x the x coordinate
     * @param y the y coordinate
     * @param finalDrawing whether this is a final drawing
     */
    public void drawRectangle(int x, int y,Boolean finalDrawing) {
        //first time calling this method drawing the same shape
        int px = Math.min(prevX,x);
        int py = Math.min(prevY,y);
        int pw=Math.abs(prevX-x);
        int ph=Math.abs(prevY-y);
        if(firstDrag){
            drawingModel.addComponent(new ShapeComponent(new Rectangle(px, py, pw, ph),new BasicStroke(4.f),color));
            firstDrag = false;
        }else{
            ((Rectangle)((ShapeComponent)drawingModel.getCurrentComponent()).getShape()).setBounds(px,py,pw,ph);
        }
        repaint();
        if(finalDrawing){
            firstDrag = true;
        } 
    }
    
    /**
     * Draws a star
     * @param x
     * @param y
     * @param finalDrawing if this is the final state of the drawing
     */
    public void drawStar(int x, int y,Boolean finalDrawing)
    {
        int px = Math.min(prevX,x);
        int py = Math.min(prevY,y);
        int pw = Math.abs(prevX-x);
        int ph = Math.abs(prevY-y);
        double radius = (pw+ph)/2;
        //first time calling this method drawing the same shape
        if(firstDrag){
            drawingModel.addComponent(new ShapeComponent(new Polygon(),new BasicStroke(4.f),color));
            firstDrag = false;
        }
        ((Polygon)((ShapeComponent)drawingModel.getCurrentComponent()).getShape()).reset();
        for (int i = 0; i < 11; i++)
        {
            double iRadius = (i % 2 == 0) ? radius : (radius * 0.5);
            double angle = (i * 360.0) / (2*5);
            int xp = (int) (px + iRadius * Math.cos(Math.toRadians(angle - 90)));
            int yp = (int) (py + iRadius * Math.sin(Math.toRadians(angle - 90)));
            ((Polygon)((ShapeComponent)drawingModel.getCurrentComponent()).getShape()).addPoint(xp, yp);
        }
        repaint();
        if(finalDrawing){
            firstDrag = true;
        }
    }

    public void drawOval(int x, int y,Boolean finalDrawing) {
        //first time calling this method drawing the same shape
        int px = Math.min(prevX,x);
        int py = Math.min(prevY,y);
        int pw=Math.abs(prevX-x);
        int ph=Math.abs(prevY-y);
        if(firstDrag){
            drawingModel.addComponent(new ShapeComponent(new Ellipse2D.Float(px, py, pw, ph),new BasicStroke(4.f),color));
            firstDrag = false;
        }else{
            ((Ellipse2D)((ShapeComponent)drawingModel.getCurrentComponent()).getShape()).setFrame(px,py,pw,ph);
        }
        repaint();
        if(finalDrawing){
            firstDrag = true;
        } 
    }

    public void drawTriangle(int x, int y, boolean finalDrawing)
    {
        int px = Math.min(prevX,x);
        int py = Math.min(prevY,y);
        int pw=Math.abs(prevX-x);
        int ph=Math.abs(prevY-y);
        int[] xPoints = new int[] {px, px + pw, px + (pw / 2)};
        int[] yPoints = new int[] {py + ph, py + ph, py};
        if(firstDrag){
            drawingModel.addComponent(new ShapeComponent(new Polygon(xPoints, yPoints, 3),new BasicStroke(4.f),color));
            firstDrag = false;
        }else{
            Polygon polygon = ((Polygon) ((ShapeComponent)drawingModel.getCurrentComponent()).getShape());
            polygon.reset();
            for(int i = 0;i<xPoints.length;i++){
                polygon.addPoint(xPoints[i], yPoints[i]);
            }
        }
        repaint();
        if(finalDrawing){
            firstDrag = true;
        } 
    }

    public void drawArror(int x, int y, boolean finalDrawing)
    {
        // calculate the distance and angle between start and end points
        double dx = x - prevX;
        double dy = y - prevY;
        double distance = Math.sqrt(dx * dx + dy * dy);
        double angle = Math.atan2(dy, dx);

        // calculate the dimensions of the arrow
        int arrowLength = (int) (distance / 2);
        int arrowWidth = (int) (arrowLength / 2);

        // calculate the points of the arrow
        int[] xPoints = new int[] { prevX, x, (int) (x - arrowLength * Math.cos(angle) - arrowWidth * Math.sin(angle)),
            x, (int) (x - arrowLength * Math.cos(angle) + arrowWidth * Math.sin(angle)), x };
        int[] yPoints = new int[] { prevY, y, (int) (y - arrowLength * Math.sin(angle) + arrowWidth * Math.cos(angle)),
            y, (int) (y - arrowLength * Math.sin(angle) - arrowWidth * Math.cos(angle)), y };    

        if(firstDrag){
            drawingModel.addComponent(new ShapeComponent(new Polygon(xPoints, yPoints, 6),new BasicStroke(4.f),color));
            firstDrag = false;
        }else{
            Polygon polygon = ((Polygon) ((ShapeComponent)drawingModel.getCurrentComponent()).getShape());
            polygon.reset();
            for(int i = 0;i<xPoints.length;i++){
                polygon.addPoint(xPoints[i], yPoints[i]);
            }
        }
        repaint();
        if(finalDrawing){
            firstDrag = true;
        } 
    }

    public void drawStraightLine(int x , int y, boolean finalDrawing)
    {
        if (firstDrag) {
            drawingModel.addComponent(new ShapeComponent(new Line2D.Double(prevX, prevY, x, y), new BasicStroke(4.f), color));
            firstDrag = false;
        } else {
            ((Line2D.Double) ((ShapeComponent)drawingModel.getCurrentComponent()).getShape()).setLine(prevX, prevY, x, y);
        }
        repaint();
        if (finalDrawing) {
            firstDrag = true;
        }
    }

    /**
     * erases part of the canvas by drawing the background colour
     * @param x
     * @param y
     */
    private void erase(int x, int y, Boolean finalDrawing){
        if(firstDrag){
            Path2D.Float p = new Path2D.Float();
            p.moveTo(x, y);
            drawingModel.addComponent(new ShapeComponent(p,new BasicStroke(strokeWidth,BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND),bkgdColor));
            firstDrag = false;
        }else{
            ((Path2D)((ShapeComponent)drawingModel.getCurrentComponent()).getShape()).lineTo(x, y);
        }
        setPrev(x,y);
        repaint();
        if(finalDrawing){
            firstDrag = true;
        }
    }

    private void fillTool(int initX, int initY)
    {
        BufferedImage bufImage = (BufferedImage)(this.createImage(this.getWidth(),this.getHeight()));
        this.render(bufImage.createGraphics(),false);
        int oldColor = bufImage.getRGB(initX, initY);
        int rgbInt = color.getRGB();
        if(oldColor != rgbInt){
            int width = bufImage.getWidth();
            int height = bufImage.getHeight();
            Stack<Point> stack = new Stack<Point>();
            stack.push(new Point(initX,initY));
            setDrawingMode(61);
            //while stack has things in it
            while(!stack.isEmpty()){
                Point p = stack.pop();
                int x = p.x;
                int y = p.y;
                if(x<0 || x>= width || y<0 || y>= height ){
                    //next 
                    continue;
                }
                if(bufImage.getRGB(x, y) != oldColor){
                    //next
                    continue;
                }
                //System.out.println("\nx: " + x + "y: " +y + "\n");
                bufImage.setRGB(x, y, rgbInt);
                stack.push(new Point(x-1,y));
                stack.push(new Point(x+1,y));
                stack.push(new Point(x,y-1));
                stack.push(new Point(x,y+1));
            }
            drawingModel.addComponent(new ImageComponent(bufImage));
            repaint();
            setDrawingMode(6);
        }
    }

    public void startFloodFill(int x, int y, int oldColor, int newColor){
        BufferedImage bufImage = (BufferedImage)(this.createImage(this.getWidth(),this.getHeight()));
        this.render(bufImage.createGraphics(),false);
        drawingModel.addComponent(new ImageComponent(bufImage));
        floodFill(x, y, oldColor, newColor, bufImage);
    }

    private void floodFill(int x, int y, int oldColor, int newColor, BufferedImage bufImage){
        if(x<0 || x> bufImage.getWidth() || y<0 || y> bufImage.getHeight() ){
            return;
        }
        if(bufImage.getRGB(x, y) != oldColor){
            return;
        }
        bufImage.setRGB(x, y, newColor);
        repaint();
        floodFill(x-1, y, oldColor, newColor,bufImage);
        floodFill(x+1, y, oldColor, newColor,bufImage);
        floodFill(x, y-1, oldColor, newColor,bufImage);
        floodFill(x, y+1, oldColor, newColor,bufImage);
    }

    public void eyeDropper(int x, int y){
        BufferedImage bufImage = (BufferedImage)(this.createImage(this.getWidth(),this.getHeight()));
        this.render(bufImage.createGraphics(),false);
        color = new Color(bufImage.getRGB(x, y));
        //System.out.println(color);
    }

    /**
     * undo
    */
    public void undo(){
        drawingModel.undo();
        repaint();
    }

    /**
     * redo
     */
    public void redo(){
        drawingModel.redo();
        repaint();
    }

    /**
     * 
     * @param x 
     * @param y
     * @param finalDrawing
     * 
     * save the area selected( a rectangle) as a bufferedImage adn point it to the golbal variable selectedArea
     * 
     */
    public void areaSelect(int x, int y,Boolean finalDrawing){
        BufferedImage wholeImage = new BufferedImage(getWidth(), getHeight(), BufferedImage.TYPE_INT_RGB);

        //first time calling this method 
        int px = Math.min(prevX,x);
        int py = Math.min(prevY,y);
        int pw=Math.abs(prevX-x);
        int ph=Math.abs(prevY-y);
        if(firstDrag){
            firstDrag = false;
        }else{
            //((Rectangle)((ShapeComponent)drawingModel.getCurrentComponent()).getShape()).setBounds(px,py,pw,ph);
        }
        
        if(finalDrawing){
            firstDrag = true;
            Graphics2D g2d = wholeImage.createGraphics();
            print(g2d);

            BufferedImage subImage = wholeImage.getSubimage(px, py, pw, ph);

            selecetedArea = subImage;
            //setDrawingMode(13);//set to paste image mode
            //return subImage;
        }        
    }

    /**
     * 
     * @param x x coordinate to paste the image
     * @param y y coordinate to paste the image
     * @param finalDrawing  
     * 
     * pastes the image ( selectedArea ) to the selected x,y coordinates
     * 
     */
    public void pasteImage(int x, int y,boolean finalDrawing){

        if(selecetedArea == null){
            return;
        }

        if(firstDrag){
            firstDrag = false;
            BufferedImage bufImage = new BufferedImage(getWidth(), getHeight(), BufferedImage.TYPE_INT_RGB);

            Graphics2D g2d = bufImage.createGraphics();
            //print(g2d);

            this.render(g2d,false);

            g2d.drawImage(selecetedArea, x, y, null);

            drawingModel.addComponent(new ImageComponent(bufImage));
            repaint();
            
        }

        if(finalDrawing){
            firstDrag = true;
        }

    }


    /**
     * 
     * @param file file path to the selected image to import
     * 
     * imports a selected image file
     * resize it to 60x60
     * point it to global variable selectedArea
     */
    public void importImage(File file){
        try{
            BufferedImage importedImage = ImageIO.read(file);

            BufferedImage resizedImage = new BufferedImage(60, 60, BufferedImage.TYPE_INT_ARGB);
            Graphics2D g2d = resizedImage.createGraphics();
            g2d.drawImage(importedImage, 0, 0, 60, 60, null);
            selecetedArea = resizedImage;
            setDrawingMode(15);
            g2d.dispose();

        }
        catch(Exception e){
            System.out.println("cannot import file");
        }
        

    }


    /**
     * saves the image as a PNG
     * @param file a File object
     */
    public void saveAsPNG(File file) {
        BufferedImage image = new BufferedImage(getWidth(), getHeight(), BufferedImage.TYPE_INT_RGB);
        Graphics2D g2d = image.createGraphics();
        print(g2d);
        try {
            ImageIO.write(image, "png", file);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    /**
     * saves the undoStack to allow the image data to be rebuilt
     * @param file the file to write to
     */
    public void saveState(File file){
        try {
            FileOutputStream fileOut = new FileOutputStream(file.getAbsoluteFile());
            ObjectOutputStream out = new ObjectOutputStream(fileOut);
            out.writeObject(drawingModel.getComponentsToRender());
            out.close();
            fileOut.close();
        } catch (IOException i) {
            i.printStackTrace();
        }
    }

    public void select(int x, int y){
        Boolean selected = false;
        for(DrawingComponent i: drawingModel.getComponentsToRender()){
            if(i instanceof ShapeComponent){
                if(((ShapeComponent)i).getShape().getBounds2D().contains(x,y)){
                    drawingModel.setCurrentComponent(i);
                    repaint();
                    selected = true;
                    //System.out.println(((ShapeComponent)i).getShape());
                    if(((ShapeComponent)i).getShape() instanceof Rectangle){
                        this.setDrawingMode(-2);
                    }
                    else if(((ShapeComponent)i).getShape() instanceof Polygon){
                        this.setDrawingMode(-3);
                    }
                    else if(((ShapeComponent)i).getShape() instanceof Ellipse2D){
                        this.setDrawingMode(-4);
                    }
                    else if(((ShapeComponent)i).getShape() instanceof Line2D){
                        this.setDrawingMode(-5);
                    }
                    break;
                }
            }
        }
        if(!selected){
            drawingModel.deSelectComponent();
            repaint();
        }
    }

    public void resizeRectangle(int x, int y, Boolean finalDrawing){
        Rectangle r;
        if(firstDrag){
            r = (Rectangle)((Rectangle)((ShapeComponent)drawingModel.getCurrentComponent()).getShape()).clone();
            ((ShapeComponent)drawingModel.getCurrentComponent()).setShape(r);
            firstDrag = false;
        }else{
            r = (Rectangle)((ShapeComponent)drawingModel.getCurrentComponent()).getShape();
        }
        double x1 = r.getX();
        double x2 = x1+r.getWidth();
        double y1 = r.getY();
        double y2 = y1+r.getHeight();
        Boolean resized = false;

        if(x<x1+10 && x>x1-10){
            r.setLocation(x, (int)y1);
            r.setSize((int)(x2-x),(int)r.getHeight());
            resized = true;
        }if(x<x2+10 && x>x2-10){
            r.setSize((int)(x-x1), (int)r.getHeight());
            resized = true;
        }if(y<y1+10 && y>y1-10){
            r.setLocation((int)x1, y);
            r.setSize((int)r.getWidth(),(int)(y2-y));
            resized = true;
        }if(y<y2+10 && y>y2-10){
            r.setSize((int)r.getWidth(), (int)(y-y1));
            resized = true;
        }
        if (!r.contains(x,y) && !resized){
            drawingModel.deSelectComponent();
            this.setDrawingMode(-1);
        }
        repaint();
        if(finalDrawing){
            firstDrag = true;
        }
    }

    public void resizeOval(int x, int y, Boolean finalDrawing){
        Ellipse2D o;
        if(firstDrag){
            o = (Ellipse2D)((Ellipse2D)((ShapeComponent)drawingModel.getCurrentComponent()).getShape()).clone();
            ((ShapeComponent)drawingModel.getCurrentComponent()).setShape(o);
            firstDrag=false;
        }else{
            o = (Ellipse2D)((ShapeComponent)drawingModel.getCurrentComponent()).getShape();
        }
    
        Rectangle2D r = (Rectangle2D)o.getBounds2D();
        double x1 = r.getX();
        double x2 = x1+r.getWidth();
        double y1 = r.getY();
        double y2 = y1+r.getHeight();

        if(x<x1+10 && x>x1-10){
            o.setFrame(x, (int)y1,(int)(x2-x),(int)r.getHeight());
        }else if(x<x2+10 && x>x2-10){
            o.setFrame(x1,y1,(int)(x-x1), (int)r.getHeight());
        }else if(y<y1+10 && y>y1-10){
            o.setFrame((int)x1, y, (int)r.getWidth(),(int)(y2-y));
        }else if(y<y2+10 && y>y2-10){
            o.setFrame(x1, y1, (int)r.getWidth(), (int)(y-y1));
        }else if (r.contains(x,y)){

        }else{//deselects shape
            drawingModel.deSelectComponent();
            this.setDrawingMode(-1);
        }
        repaint();
        if(finalDrawing){
            firstDrag = true;
        }
    }

    public void resizeLine(int x, int y, Boolean finalDrawing){
        Line2D l;
        if(firstDrag){
            l = (Line2D)((Line2D)((ShapeComponent)drawingModel.getCurrentComponent()).getShape()).clone();
            ((ShapeComponent)drawingModel.getCurrentComponent()).setShape(l);
            firstDrag=false;
        }else{
            l = (Line2D)((ShapeComponent)drawingModel.getCurrentComponent()).getShape();
        }
        Rectangle2D r = (Rectangle2D)l.getBounds2D();
        double x1 = r.getX();
        double x2 = x1+r.getWidth();
        double y1 = r.getY();
        double y2 = y1+r.getHeight();

        if(x<x1+10 && x>x1-10){
            l.setLine(x, y1, x2, y2);
        }else if(x<x2+10 && x>x2-10){
            l.setLine(x1,y1, x, y2);
        }else if(y<y1+10 && y>y1-10){
            l.setLine(x1, y, x2, y2);
        }else if(y<y2+10 && y>y2-10){
            l.setLine(x1, y1, x2, y);
        }else if (r.contains(x,y)){

        }else{//deselects shape
            drawingModel.deSelectComponent();
            this.setDrawingMode(-1);
        }
        repaint();
        if(finalDrawing){
            firstDrag = true;
        }
    }

    public void resizePolygon(int x, int y, Boolean finalDrawing){
        // Polygon p = (Polygon)((ShapeComponent)drawingModel.getCurrentComponent()).getShape();
        // ArrayList<Integer> xPoints = new ArrayList<Integer>();
        // ArrayList<Integer> yPoints = new ArrayList<Integer>();
        // for (int i = 0; i<p.xpoints.length;i++){
        //     xPoints.add(new Integer(p.xpoints[i]));
        //     yPoints.add(new Integer(p.ypoints[i]));

        // }

        // Rectangle r = (Rectangle)p.getBounds2D();
        // double x1 = r.getX();
        // double x2 = x1+r.getWidth();
        // System.out.println(x2);
        // double y1 = r.getY();
        // double y2 = y1+r.getHeight();

        // if(x<x1+10 && x>x1-10){

        // }else if(x<x2+10 && x>x2-10){//get this working
        //     int minX = 10000000;
        //     int pos;
        //     int i;
        //     for(i=0;i<xPoints.size();i++){
        //         if(xPoints.get(i)<minX){
        //             minX=xPoints.get(i);
        //             pos=i;
        //         }
        //     }
        //     Collections.rotate(xPoints,-i);
        //     Collections.rotate(yPoints,-i);
        //     double modifier = (x-x1)/(x2-x1);
        //     p.reset();
        //     p.addPoint(xPoints.get(0), yPoints.get(0));
        //     for(int n = 1;n<xPoints.size();n++){
        //         p.addPoint((int)((xPoints.get(0)+((xPoints.get(n)-xPoints.get(0))*modifier))), yPoints.get(n));
        //     }
        // }else if(y<y1+10 && y>y1-10){

        // }else if(y<y2+10 && y>y2-10){

        // }else if (r.contains(x,y)){

        // }else{//deselects shape
        //     drawingModel.deSelectComponent();
        //     this.setDrawingMode(-1);
        // }
        // repaint();
    }

    public void textBox(int x, int y, boolean finalDrawing)
    {
        if(firstDrag){
            drawingModel.addComponent(new StringTextComponent("",x,y,null,color));
            TextBoxWindow t = new TextBoxWindow("Add Text", this);
            firstDrag=false;
        }
        setPrev(x,y);
        repaint();
        if(finalDrawing){
            firstDrag = true;
        }
    }

    public void setTextComponentString(String text){
        if(drawingModel.getCurrentComponent() instanceof StringTextComponent){
            ((StringTextComponent)(drawingModel.getCurrentComponent())).setText(text);
            repaint();
        }
    }

    /**
     * performs a cut operation
     * @return the component that has been cut
     */
    public DrawingComponent cut()
    {
        try{
            repaint();
            DrawingComponent c = (DrawingComponent)drawingModel.getCurrentComponent().clone();
            drawingModel.getCurrentComponent().setDeleted(true);
            drawingModel.deSelectComponent();
            return c;
        }catch(Exception e){
            return null;
        }
    }

    public DrawingComponent copy()
    {
        try{
            repaint();
            return (DrawingComponent)drawingModel.getCurrentComponent().clone();
        }catch(Exception e){
            return null;
        }
    }

    /**
     * pastes a {@link DrawingComponent} into the canvas at the same loca
     * @param drawingComponent
     */
    public void paste(DrawingComponent drawingComponent)
    {
        if(drawingComponent!=null){
            System.out.println("pasting");
            drawingModel.addComponent(drawingComponent);
            repaint();
        }
    }

}