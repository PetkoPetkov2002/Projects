import javax.lang.model.element.Element;
import javax.swing.*;
import java.awt.geom.AffineTransform;
import java.awt.*;
import java.awt.event.*;
import java.awt.Color;

public class Window extends JFrame implements MouseListener, MouseMotionListener, MouseWheelListener
{
    private double zoomlevel = 1.0; 
   
    private CanvasManager canvasManager;
    private ImageTabs imageTabs;
    private NewFileDialogue newFileDialogue = new NewFileDialogue(this,new ActionListener(){
        public void actionPerformed(ActionEvent e){
            try{
                CanvasWrapper newFile = new CanvasWrapper(newFileDialogue.getFileName(),Integer.parseInt(newFileDialogue.getCanvasWidth()),Integer.parseInt(newFileDialogue.getCanvasHeight()));
                canvasManager.addCanvasWrapper(newFile, true);
                imageTabs.addDrawingCanvas(canvasManager.getCurrentCanvasWrapper());
                canvasManager.setCurrentCanvas(0);
                newFileDialogue.dispose();
            }catch(Exception ex){
                
            }
    }});

    public Window(CanvasManager canvasManager){
        
        this.canvasManager=canvasManager;
        canvasManager.addCanvasWrapper(new CanvasWrapper("file1",600,600),true);
        imageTabs = new ImageTabs(this,canvasManager);
        UIManager.put("MenuBar.background", Color.PINK);
        JPanel mainPanel= new JPanel();                                            
        mainPanel.setBackground(Color.PINK);
        mainPanel.setBounds(0, 0, 1000 , 900);
        this.setContentPane(mainPanel);
        canvasManager.getCurrentCanvas().setPreferredSize(new Dimension(600, 600));
        imageTabs.addDrawingCanvas(canvasManager.getCurrentCanvasWrapper());
        mainPanel.add(imageTabs);
        this.setJMenuBar(new MainMenuBar(canvasManager,newFileDialogue,imageTabs));
        JPanel panel = new JPanel();
        panel.setLayout(new BorderLayout());
        ButtonPanel buttonPanel = new ButtonPanel(canvasManager);
        panel.add(buttonPanel,BorderLayout.SOUTH);
        panel.add(new BrushWidthSlider(canvasManager),BorderLayout.NORTH);
        mainPanel.add(panel);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setLocationRelativeTo(null);
        this.setSize(1000,1000);
        this.setPreferredSize(new Dimension(1000,1000));
        this.pack();
        this.setVisible(true); 
        mainPanel.addMouseWheelListener(this); 
    }
    
    public void mouseWheelMoved(MouseWheelEvent e){}
   
    public void mouseClicked(MouseEvent e){}
 
    public void mouseMoved(MouseEvent e){}
 
    public void mouseDragged(MouseEvent e)
    {
        canvasManager.getCurrentCanvas().draw(e.getX(), e.getY(),false);
    }
 
    public void mouseExited(MouseEvent e){}
 
    public void mouseEntered(MouseEvent e){}
 
    public void mouseReleased(MouseEvent e)
    {
        canvasManager.getCurrentCanvas().draw(e.getX(), e.getY(),true);
        canvasManager.getCurrentCanvas().resetPrev();
    }
 
    public void mousePressed(MouseEvent e)
    {
        canvasManager.getCurrentCanvas().draw(e.getX(), e.getY(),false);//moved from clicked to pressed as it is wanted on the down click
        //canvasManager.getCurrentCanvas().setPrev(e.getX(), e.getY());
    }
}