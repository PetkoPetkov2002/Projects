import javax.swing.JPanel;

class ComponentPanel extends JPanel {
    
    private DrawingModel drawingModel;

    ComponentPanel(DrawingModel drawingModel){
        this.drawingModel = drawingModel;
    }
}