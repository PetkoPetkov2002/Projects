public class Sun extends SolarObject{
   
    ///initiates the constructor of SolarObject class with the variables used in main.
    public Sun(SolarSystem ss,double SunDistance,double SunAngle, double SunDiameter, String SunColour,double SunVelocity){
        super(ss, SunDistance,SunAngle,SunDiameter,SunColour,SunVelocity);



        
    }
    ///function to draw sun 
    public void exist(){
        ///this is a function that draws the orbit of the planet its from the Solar System class
        ss.drawSolarObject(ObjectDistance,ObjectAngle,ObjectDiameter,ObjectColour);
        

    }
}