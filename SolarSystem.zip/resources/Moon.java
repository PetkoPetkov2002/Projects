public class Moon extends SolarObject{
    double ParentDistance;
    double ParentVelocity;
    double ParentAngle;
    ///initiates the constructor of SolarObject class with the variables used in main.
    public Moon(SolarSystem ss,double MoonDistance, double MoonAngle,double MoonDiameter,String MoonColour,double MoonSpeed,double ParentDistance,double ParentAngle,double ParentVelocity){
    
        super(ss,MoonDistance,MoonAngle,MoonDiameter,MoonColour,MoonSpeed);
        this.ParentDistance = ParentDistance;
        this.ParentVelocity = ParentVelocity;
        this.ParentAngle = ParentAngle;


    }
    ///makes the moon orbit
    public void move(){
        ///this is a function that draws the orbit of the moon its from the Solar System class
        ParentAngle+=ParentVelocity;
        ss.drawSolarObjectAbout(ObjectDistance,ObjectAngle+=ObjectVelocity,ObjectDiameter,ObjectColour,ParentDistance,ParentAngle);
        
        
    }
    

}