public class Planet extends SolarObject{
    ///initiates the constructor of SolarObject class with the variables used in main.
    public Planet(SolarSystem ss,double ObjectDistance,double ObjectAngle,double ObjectDiameter,String ObjectColour,double ObjectVelocity){
            super(ss,ObjectDistance,ObjectAngle,ObjectDiameter,ObjectColour,ObjectVelocity);

    }

    
    /// function that makes the planet orbit
    public void move(){
        ///updates the position of the planet
        ObjectAngle+=ObjectVelocity;
        ///this is a function that draws the orbit of the planet its from the Solar System class
        ss.drawSolarObjectAbout(ObjectDistance,ObjectAngle,ObjectDiameter,ObjectColour,0,0);
        
        
        
            
            
        
    }
}