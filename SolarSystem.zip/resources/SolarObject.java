/**
 * This is the parent class it has all the variables a solar object would need for this program
 */
public class SolarObject{
    double ObjectVelocity;
    double ObjectDistance;
    double ObjectAngle;
    double ObjectDiameter;
    String ObjectColour;
    double ParentDistance;
    double ParentAngle;
    double ParentVelocity;
    public SolarSystem ss;
    /**
     * Innitiates all the variables for a SolarObject
     * @param ss - the solar system instance that the solar object will exist in
     * @param ObjectDistance - the distance that the object is away from the sun
     * @param ObjectAngle - the angle the object is in comparrison to the suns orbit
     * @param ObjectDiameter- the objects diameter
     * @param ObjectColour - the object's colour
     * @param ObjectVelocity - the velocity of the object
     * @param ParentDistance - the distance of the parent object from the sun
     * @param ParentAngle - the angle the parent object is in comparrison to the sun
     * @param ParentVelocity - the velocity of the paernt object 
     */
    public SolarObject(SolarSystem ss,double ObjectDistance,double ObjectAngle, double ObjectDiameter, String ObjectColour, double ObjectVelocity){
        
        this.ss = ss;
        this.ObjectDistance = ObjectDistance;

        this.ObjectAngle = ObjectAngle;

        this.ObjectDiameter = ObjectDiameter;
        this.ObjectColour = ObjectColour;
        this.ObjectVelocity = ObjectVelocity;

        ///this.ParentDistance = ParentDistance;
        ///this.ParentAngle = ParentAngle;
        ///this.ParentVelocity = ParentVelocity;
    }
    ///getters for velocity distance and agle this is useful for when making a moon, since we require a "parent" velocity,distance and angle, i.e the velocity, distance and angle of the planet the moon is orbitting around. 
    public double getVelocity(){
        return ObjectVelocity;
    }
    public double getDistance(){
        return ObjectDistance;
    }
    public double getAngle(){
        return ObjectAngle;
    }


}