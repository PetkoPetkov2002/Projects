public class Main {
    

    
    
    /**
     * Constructor for main, this is the "driver of the program"
     * 
     */
    public static void main(String[] args){
        ///creation of objects
        SolarSystem ss = new SolarSystem(2000,1000);
        Planet earth = new Planet(ss,300,40,35,"BLUE",2.2);
        Moon moon = new Moon(ss,50,40,20,"WHITE",6,earth.getDistance(),earth.getAngle(),earth.getVelocity());
        Sun sun = new Sun(ss,0,50,100,"YELLOW",20);
        Planet mercury = new Planet(ss,200,40,30,"YELLOW",2.9);
        Planet venus  = new Planet(ss,245,40,30,"YELLOW",2.5);
        Planet mars = new Planet(ss,370,40,30,"RED",2.1);
        Planet jupiter = new Planet(ss,500,40,80,"ORANGE",2.0);
        Planet saturn = new Planet(ss,590,40,30,"GREEN",1.8);
        Planet uranus = new Planet(ss,700,40,30,"BLUE",1.5);
        Planet neptune = new Planet(ss,770,40,40,"BLUE",1.25);
        Moon moon_jupiter = new Moon(ss,50,40,10,"WHITE",10,jupiter.getDistance(),jupiter.getAngle(),jupiter.getVelocity());
        Moon moon2_jupiter = new Moon(ss,75,40,9,"WHITE",8,jupiter.getDistance(),jupiter.getAngle(),jupiter.getVelocity());
        Moon moon3_jupiter = new Moon(ss,85,40,10,"WHITE",9,jupiter.getDistance(),jupiter.getAngle(),jupiter.getVelocity());
        Moon moon4_jupiter = new Moon(ss,95,40,10,"WHITE",5,jupiter.getDistance(),jupiter.getAngle(),jupiter.getVelocity());
        

        
       
        


        /// While loop that starts the orbit of the planets
        
        while(true){
            sun.exist();
            earth.move();
            moon.move();
            mercury.move();
            venus.move();
            mars.move();
            saturn.move();
            uranus.move();
            neptune.move();
            jupiter.move();
            moon_jupiter.move();
            moon2_jupiter.move();
            moon3_jupiter.move();
            moon4_jupiter.move();
            ss.finishedDrawing();
        }
        
        
        
        
        
        
        
    }
}
